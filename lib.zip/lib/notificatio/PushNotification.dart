class PushNotification {
  PushNotification({
    this.title,
    this.body,
    this.dataTitle,
    this.dataBody,
    this.content,
    this.id,
  });

  String? title;
  String? body;
  String? dataTitle;
  String? dataBody;
  String? content;
  String? id;
}
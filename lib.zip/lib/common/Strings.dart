class Strings {


  static bool ChatWindowCLosed=false;

// login widget

  static const String paystackPublicKey = 'pk_test_33f3b386fd00574c7230cc8276dd5d9100902c8f';

  static  bool riderChatRunning=false;

  static const String appName = 'Foodeze';
  static const String done = 'Done';
  static const String cart = 'Cart';
  static const String totalPay = "Total Pay ";
  static const String catering = " Catering";
  static const String addToCateringReq = 'Add To Catering Request';
  static const String cateringReq =  " Catering Request";
  static const String pleaseSelectAddress = "Please select address";
  static const String continue_with_Number = 'Continue with Number';
  static const String success_msg = 'Profile Successfully Updated';
  static const String success_created = 'Profile Successfully Created';
  static const String success_address = 'Address Successfully Added';
  static const String success_address_delete = 'Address Successfully Deleted';
  static const String success_rate = 'Rate Successfully Submited';
  static const String success_event = 'Event Successfully Created';
  static const String success_catering= 'Catering  Successfully Created';
  static const String payment_Success = 'Payment  Successfully Done';
  static const String image_msg = 'Image Successfully Updated';
  static const String went_wrong = "Something is went wrong. Please try again later";
  static const String curfewTitle = "COVID-19 Protocols Operating times (Alert Level Dependent).";
  static const String curfewSubTitle = "We will not be able to deliver take-aways at this current time due to a mandatory curfew in your country, you can continue to place catering requests and RSVP for events";
  static const String checkInternet = "Please check your internet connection";
  static const String checkMobile = "Please enter your mobile number";
  static const String enterOTP = "Please enter OTP";
  static const String otpNotMatched =  "OTP not matched";
  static const String addedToFav =  "Added to favourite";
  static const String orderStatus =  " Order Status";
  static const String extraItemSuccess =  "Extra Item Added Successfully";
  static const String cartSuccess =  "Item Added To Cart";
  static const String itemAdded =  "Item Added";
  static const String cardSuccess =  "Card Details  Added Successfully";
  static const String selectQty =  "Please Select Item Quantity";
  static const String added =  "Added";
  static const String menuItem =  "   Menu Item";
  static const String extraItem =  "   Extra Item";
  static const String paymentSuccess =  " Payment Success";
  static const String couponCodeEnter =  "Please enter coupon code";
  static const String couponCodeInvalid =  "Coupon code is  invalid";
  static const String couponCodeApplied =  "Coupon code is  applied";
  static const String checkout =  "Checkout";
  static const String noCartItem =  "Nothing Here \n\nCheckout great food & offers";


  static const String placedOrder =  "Your order has been placed";
  static const String riderChat =  "Customer to rider chat";
  static const String kithchenRate =  "Virtual kitchen rate";
  static const String riderRate =  "Rider rate";

  static const String kindlyRate =  "Kindly rate";
  static const String chatRider =  "Rider Chat";
  static const String addCard =  "Add Card Details";






  static const String rider =  "rider";
  static const String vk =  "vk";

// phone widget

  static const String whats_Your_Number = "What's Your\nNumber";
  static const String createProfile = "Create Profile";
  static const String we_protect = "We Protect our community by\nmaking sure everyone on Foodeze\nis real.";
  static const String next = 'Next';
  static const String logout = 'Logout';
  static const String submit = 'Submit';
  static const String update = 'Update';
  static const String addToCart = 'Add to Cart';
  static const String addItem = 'Add Item';
  static const String showAddress = 'Show Address';
  static const String save = 'Save';
  static const String addAddress = 'Add Address';
  static const String address = 'Address';
  static const String noAddress = 'No Address Added';
  static const String selectOptions = 'Select Options';
  static const String viewCart = 'View Cart';
  static const String addNew = 'Add New';
  static const String repeatLast = 'Repeat Last';
  static const String creatNewTicket = 'Create New Ticket';
  static const String creatNewEvent = 'Create New Event';
  static const String resolved = 'Issue is resolved';
  static const String homeDel = 'Home Delivery';
  static const String delivery = 'Delivery';
  static const String pickup = 'Pickup';
  static const String home = 'Home';
  static const String selectAddress = 'Select Address';
  static const String applycoupon = 'Apply Coupon';

  // OTP widget
  static const String we_can = "We have sent you a SMS code";
  static const String on_Number = 'On Number  ';
  static const String resend_OTP = 'Resend OTP';
  static const String email = 'Email';
  static const String fName = 'First Name';
  static const String comment = 'Comment (max 200 characters)';
  static const String comment2 = 'Comment';
  static const String lName = 'Last Name';
  static const String allProducts = 'All Products';
  static const String virtualKithenPromote = 'Virtual Kitchen Promote';
  static const String virtualKithcennearYou = 'Virtual Kitchen Near You';
  static const String whatsNew = 'Whats New';
  static const String myFvrt = 'My Favourite';
  static const String mostPopular = 'Most Popular';
  static const String add = 'ADD';
  static const String pay = 'PAY';
  static const String view = 'View';
  static const String pending = 'Pending';
  static const String payNow = 'Pay Now';
  static const String completed = 'Completed';
  static const String rejected = 'Rejected';
  static const String scheduled = 'Scheduled';
  static const String enterSubject = 'Enter Subject';
  static const String adminChat = 'Admin Chat';
  static const String noEventFound = 'Sorry.The restaurants does not have any event at this point';
  static const String noEventHistory = 'No Event History Found';
  static const String noOrderHistory = 'No Order History Found';

  static const String cateringLocation = 'Catering Location';
  static const String cateringCity = 'Catering City';
  static const String cateringProvince = 'Catering Province';
  static const String cateringTitle = 'Catering Title';
  static const String cateringDesc = 'Catering Description';
  static const String eventTitle = 'Event Title';
  static const String event = 'Event';
  static const String eventDesc = 'Event Description';
  static const String eventDate = 'Event Date';
  static const String date = 'Date';
  static const String delPickTime = 'Delivery/Pickup Time';
  static const String comments = 'Comments';
  static const String time = 'Time';
  static const String hours = 'Hours';
  static const String cateringMenu = 'Catering Menu';
  static const String cateringMenuItem = 'Catering Menu Item';
  static const String eventHours = 'Event Hours';
  static const String cateringMenu2 = 'Your Menu';
  static const String eventQuantity= 'Food Quantity';
  static const String eventLocation = 'Event Location';
  static const String eventCity = 'Event City';
  static const String eventProvince = 'Event Province';
  static const String selectKitchen = 'Select Kithchen';
  static const String selectMenu = 'Select Menu';
  static const String pleaseSelectMenu = 'Please Select Menu';
  static const String pleaseSelectCateringItem = 'Please Select Catering Item';
  static const String pleaseSelectLocation = 'Please Enter Location';
  static const String pleaseSelectCity = 'Please Enter City';
  static const String pleaseSelectProvince = 'Please Enter Province';
  static const String pleaseSelectTitle = 'Please Enter Title';
  static const String pleaseSelectDescription = 'Please Enter Description';
  static const String pleaseSelectDate = 'Please Select Date';
  static const String pleaseSelectTime = 'Please Select Time';
  static const String pleaseSelectHours = 'Please Select Hours';
  static const String pleaseSelectDelPickTime = 'Please Select Delivery/Pickup Time';
  static const String riderTip = 'RIDER TIP %';
  static const String couponCode = 'Coupon Code';
  static const String instructions = 'Instructions';


  static const String accountDetails = '  Account Details';
  static const String notification = '  Notification';
  static const String message = '  Message';


  static const String street = 'Street';
  static const String houseNo = 'House No./Unit No.';
  static const String city = 'City';
  static const String state = 'State';
  static const String country = 'Country';
  static const String zipCode = 'ZipCode';
  static const String viewCatOrder = 'View Catering Order';
  static const String viewCatDetails = 'View Catering Details';
  static const String rsvp = 'RSVP';
  static const String back = 'Back';
  static const String advancePay = 'Make Advance Payment ';
  static const String cancel = 'Cancel ';
  static const String proceedPayment = 'Proceed To Payment ';





}

class PrefConstant {
  static const String USER = 'user';
  static const String FIRST_NAME = 'FIRST_NAME';
  static const String LAST_NAME = 'LAST_NAME';
  static const String EMAIL = 'EMAIL';
  static const String MOBILE = 'MOBILE';
}


import 'dart:collection';

import 'package:foodeze_flutter/common/Strings.dart';
import 'package:foodeze_flutter/modal/ApiResponseNew.dart';
import 'package:foodeze_flutter/modal/CartModal.dart';
import 'package:foodeze_flutter/modal/ExtraMenuItemModal.dart';
import 'package:foodeze_flutter/repo/ApiRepo.dart';
import 'package:get/get.dart';

class EventDetailsController extends GetxController {
  var totalQty = 1.obs;

}

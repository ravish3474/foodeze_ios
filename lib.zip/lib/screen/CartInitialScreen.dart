import 'package:flutter/material.dart';
import 'package:foodeze_flutter/screen/CartPage.dart';
import 'package:get/get.dart';
import 'package:foodeze_flutter/extensions/UtilExtensions.dart';

class CartInitialScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
  //  CartPage().navigate();
    return Container();
  }
}
